package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.Item

class Task1 extends FunSuite {

  test("your test name") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()

    var testItem: Item = new Item("test item", 100.0)

    testSelfCheckout.addItemToStore("123", testItem)
    // TODO

  }
  test("test item description") {
    val testItem: Item= new Item("test item",100.0)
    assert(testItem.description()=="test item")
    //testSelfCheckout.addItemToStore("123", testItem)
    // TODO

  }
  test("test item price") {
    val testItem: Item= new Item("test item",100.0)
    assert(Math.abs(testItem.price()-100.0)<0.001)
    //testSelfCheckout.addItemToStore("123", testItem)
    // TODO

  }
  test("test changing item price") {
    val testItem: Item= new Item("test item",100.0)
    testItem.setBasePrice(101.0)
    assert(Math.abs(testItem.price()-101.0)<0.001)
    //testSelfCheckout.addItemToStore("123", testItem)
    // TODO

  }
  test("buying an item change price") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)


    checkout.addItemToStore("472", testItem)

    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(2)

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    testItem.setBasePrice(101.0)
    assert(cart.size==1)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-101.0)<0.001)
    // TODO

  }

  test("test pushing number buttons") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout.displayString()=="")
    testSelfCheckout.numberPressed((4))
    assert(testSelfCheckout.displayString()=="4")
    testSelfCheckout.numberPressed((7))
    assert(testSelfCheckout.displayString()=="47")
    testSelfCheckout.numberPressed((2))

    assert(testSelfCheckout.displayString()=="472")

    // TODO

  }
  test("test pushing number buttons1") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout.displayString()=="")
    testSelfCheckout.numberPressed((0))
    assert(testSelfCheckout.displayString()=="0")
    testSelfCheckout.numberPressed((7))
    assert(testSelfCheckout.displayString()=="07")
    testSelfCheckout.numberPressed((2))

    assert(testSelfCheckout.displayString()=="072")

    // TODO

  }
  test("test pushing number buttons2") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout.displayString()=="")
    testSelfCheckout.numberPressed((0))
    assert(testSelfCheckout.displayString()=="0")
    testSelfCheckout.numberPressed((0))
    assert(testSelfCheckout.displayString()=="00")
    testSelfCheckout.numberPressed((2))

    assert(testSelfCheckout.displayString()=="002")

    // TODO

  }
  test("clearing numbers") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout.displayString()=="")
    testSelfCheckout.numberPressed((4))
    assert(testSelfCheckout.displayString()=="4")
    testSelfCheckout.numberPressed((7))
    assert(testSelfCheckout.displayString()=="47")
    testSelfCheckout.numberPressed((2))
    testSelfCheckout.clearPressed()

    assert(testSelfCheckout.displayString()=="")

    // TODO

  }
  test("buying an item") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(2)

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(cart.size==1)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    // TODO

  }
  test("buying an  small item") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",0.12)
    checkout.addItemToStore("002", testItem)

    checkout.numberPressed(0)
    checkout.numberPressed(0)
    checkout.numberPressed(2)

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(cart.size==1)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-0.12)<0.001)
    // TODO

  }
  test("buying an item ham") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("ham",13.0)
    checkout.addItemToStore("473", testItem)

    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(3)

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(cart.size==1)
    assert(cart.head.description()=="ham")
    assert(Math.abs(cart.head.price()-13.0)<0.001)
    // TODO

  }
  test("buying an item nonexistent") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("ham",13.0)
    checkout.addItemToStore("473", testItem)

    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(5)

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(cart.size==1)
    assert(cart.head.description()=="error")
    assert(Math.abs(cart.head.price()-0.0)<0.001)
    // TODO

  }

  test("buying two item") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    var testItem1: Item= new Item("ham",13.0)
    checkout.addItemToStore("472", testItem)
    checkout.addItemToStore("473", testItem1)

    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(2)

    checkout.enterPressed()
    //checkout.clearPressed()
    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(3)

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(cart.size==2)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(cart.last.description()=="ham")
    assert(Math.abs(cart.last.price()-13.0)<0.001)
    // TODO

  }

}
