package tests


import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.{BottleDeposit, Item, Modifier, Sale, SalesTax}
class Task3 extends FunSuite{
  val epsilon: Double = 0.0001

  def compareDoubles(d1: Double, d2: Double): Boolean = {
    Math.abs(d1 - d2) < epsilon
  }
  test("enter_noitem") {
    var checkout: SelfCheckout = new SelfCheckout()
    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(cart.size==1)
    assert(cart.head.description()=="error")
    assert(Math.abs(cart.head.price()-0.0)<0.001)
    // TODO

  }
  test("buying one item") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    assert(checkout.displayString()=="")
    checkout.numberPressed((4))
    assert(checkout.displayString()=="4")
    checkout.numberPressed((7))
    assert(checkout.displayString()=="47")
    checkout.numberPressed((2))

    assert(checkout.displayString()=="472")

    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(testItem.description()=="cheese")
    assert(Math.abs(testItem.price()-12.0)<0.001)

    assert(cart.size==1)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(compareDoubles(checkout.subtotal(),12.0))
    assert(compareDoubles(checkout.tax(),0.0))
    assert(compareDoubles(checkout.total(),12.0))
    // TODO

  }
  test("buying three items") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    assert(checkout.displayString()=="")
    checkout.numberPressed((4))
    assert(checkout.displayString()=="4")
    checkout.numberPressed((7))
    assert(checkout.displayString()=="47")
    checkout.numberPressed((2))

    assert(checkout.displayString()=="472")

    checkout.enterPressed()
    checkout.enterPressed()
    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(testItem.description()=="cheese")
    assert(Math.abs(testItem.price()-12.0)<0.001)

    assert(cart.size==3)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(compareDoubles(checkout.subtotal(),36.0))
    assert(compareDoubles(checkout.tax(),0.0))
    assert(compareDoubles(checkout.total(),36.0))
    // TODO

  }
  test("buying three items and one error") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    checkout.numberPressed((4))
    checkout.numberPressed((7))
    checkout.numberPressed((2))

    checkout.enterPressed()
    checkout.enterPressed()
    checkout.enterPressed()
    checkout.numberPressed((2))
    checkout.clearPressed()
    checkout.enterPressed()
    val cart:List[Item]=checkout.itemsInCart()

    assert(cart.size==4)
    assert(cart.head.description()=="cheese")
    assert(cart(3).description()=="error")
    assert(Math.abs(cart(3).price()-0.0)<0.001)
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(compareDoubles(checkout.subtotal(),36.0))
    assert(compareDoubles(checkout.tax(),0.0))
    assert(compareDoubles(checkout.total(),36.0))
    // TODO

  }
  test("buying three items and one error and cash loyalty before checkout") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    checkout.numberPressed((4))
    checkout.numberPressed((7))
    checkout.numberPressed((2))

    checkout.enterPressed()
    checkout.enterPressed()
    checkout.enterPressed()
    checkout.numberPressed((2))
    checkout.clearPressed()
    checkout.enterPressed()
    checkout.cashPressed()
    checkout.creditPressed()
    checkout.loyaltyCardPressed()
    val cart:List[Item]=checkout.itemsInCart()

    assert(cart.size==4)
    assert(cart.head.description()=="cheese")
    assert(cart(3).description()=="error")
    assert(Math.abs(cart(3).price()-0.0)<0.001)
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(compareDoubles(checkout.subtotal(),36.0))
    assert(compareDoubles(checkout.tax(),0.0))
    assert(compareDoubles(checkout.total(),36.0))
    // TODO

  }
  test("buying three items then checkout") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    assert(checkout.displayString()=="")
    checkout.numberPressed((4))
    assert(checkout.displayString()=="4")
    checkout.numberPressed((7))
    assert(checkout.displayString()=="47")
    checkout.numberPressed((2))

    assert(checkout.displayString()=="472")

    checkout.enterPressed()
    checkout.enterPressed()
    checkout.enterPressed()
    checkout.checkoutPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(testItem.description()=="cheese")
    assert(Math.abs(testItem.price()-12.0)<0.001)

    assert(cart.size==3)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(compareDoubles(checkout.subtotal(),36.0))
    assert(compareDoubles(checkout.tax(),0.0))
    assert(compareDoubles(checkout.total(),36.0))
    assert(checkout.displayString()=="cash or credit")
    checkout.clearPressed()
    assert(checkout.displayString()=="cash or credit")
    checkout.cashPressed()
    assert(checkout.displayString()=="")
    val cart1:List[Item]=checkout.itemsInCart()
    assert(cart1.size==0)
    // TODO

  }
  test("buying three items then checkout credit") {
    val checkout: SelfCheckout= new SelfCheckout()
    var testItem: Item= new Item("cheese",12.0)
    checkout.addItemToStore("472", testItem)

    assert(checkout.displayString()=="")
    checkout.numberPressed((4))
    assert(checkout.displayString()=="4")
    checkout.numberPressed((7))
    checkout.cashPressed()
    checkout.creditPressed()
    assert(checkout.displayString()=="47")
    checkout.numberPressed((2))

    assert(checkout.displayString()=="472")

    checkout.enterPressed()
    checkout.enterPressed()
    checkout.enterPressed()
    checkout.checkoutPressed()
    val cart:List[Item]=checkout.itemsInCart()
    assert(testItem.description()=="cheese")
    assert(Math.abs(testItem.price()-12.0)<0.001)

    assert(cart.size==3)
    assert(cart.head.description()=="cheese")
    assert(Math.abs(cart.head.price()-12.0)<0.001)
    assert(compareDoubles(checkout.subtotal(),36.0))
    assert(compareDoubles(checkout.tax(),0.0))
    assert(compareDoubles(checkout.total(),36.0))
    assert(checkout.displayString()=="cash or credit")
    checkout.clearPressed()
    assert(checkout.displayString()=="cash or credit")
    checkout.creditPressed()
    assert(checkout.displayString()=="")
    println(checkout.itemsInCart())
    val cart1:List[Item]=checkout.itemsInCart()
    assert(cart1.size==0)
    // TODO

  }
}
