package store.model.checkout

import store.model.items.Item

abstract class regState(val self:SelfCheckout) {
  def numberPressed(number: Int): Unit={}
  def clearPressed(): Unit={this.self.bcode=""}
  def enterPressed(): Unit={}
  def checkoutPressed(): Unit={}
  def cashPressed(): Unit={}
  def creditPressed(): Unit={}
  def displayString(): String={""}
  def loyaltyCardPressed(): Unit={}
  def addItemToStore(barcode: String, item: Item): Unit = {
    this.self.storestuff+=(barcode->item)
  }
  def itemsInCart(): List[Item] = {
    this.self.cartlist
  }
}
