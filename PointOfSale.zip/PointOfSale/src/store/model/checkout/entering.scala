package store.model.checkout

class entering (theReg:SelfCheckout) extends regState(theReg){
  /*
  def numberPressed(number: Int): Unit={}
  def clearPressed(): Unit={this.self.bcode=""}
  def enterPressed(): Unit={}
  def checkoutPressed(): Unit={}
  def cashPressed(): Unit={}
  def creditPressed(): Unit={}
  def displayString(): String={""}
  def loyaltyCardPressed(): Unit={}
  */
  override def enterPressed(): Unit={
    this.self.cartlist = this.self.cartlist :+ this.self.storestuff.getOrElse(this.self.bcode, self.errormessage)
  }
  override def numberPressed(number: Int): Unit={
    clearPressed()
    this.self.bcode+=number
    this.self.state=new shopping(this.self)
  }
  override def checkoutPressed(): Unit={
    this.self.state= new checkingOut(this.self)
  }
  override def displayString(): String={
    this.self.bcode
  }
}
