package store.model.checkout

class checkingOut(theReg:SelfCheckout) extends regState(theReg) {
  /*
  def numberPressed(number: Int): Unit={}
  def clearPressed(): Unit={this.self.bcode=""}
  def enterPressed(): Unit={}
  def checkoutPressed(): Unit={}
  def cashPressed(): Unit={}
  def creditPressed(): Unit={}
  def displayString(): String={""}
  def loyaltyCardPressed(): Unit={}
  */
  override def displayString(): String={
    "cash or credit"
  }
  override def cashPressed(): Unit={
    clearPressed()
    this.self.cartlist=List()

    this.self.state=new noItem(this.self)
  }
  override def creditPressed(): Unit={
    clearPressed()
    this.self.cartlist=List()
    this.self.state=new noItem(this.self)
  }
}
