package store.model.checkout

import store.model.items.Item

class noItem (theReg:SelfCheckout) extends regState(theReg){

  /*override def clearPressed(): Unit = {

    this.self.cartlist = this.self.cartlist :+ this.self.storestuff.getOrElse(this.self.bcode, self.errormessage)
  }*/
  override def enterPressed(): Unit={
    this.self.cartlist = this.self.cartlist :+ this.self.storestuff.getOrElse(this.self.bcode, self.errormessage)
    clearPressed()
  }
  /*override def displayString(): String={
    this.self.bcode
  }*/
  override def numberPressed(number: Int): Unit={
    this.self.bcode+=number
    this.self.state=new shopping(this.self)
  }

  /*
  def checkoutPressed(): Unit
  def cashPressed(): Unit
  def creditPressed(): Unit
  def displayString(): String
  def loyaltyCardPressed(): Unit
  */

}
