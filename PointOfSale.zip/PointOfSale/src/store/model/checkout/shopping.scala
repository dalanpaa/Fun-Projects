package store.model.checkout

import store.model.items.Item

class shopping(theReg:SelfCheckout) extends regState(theReg) {
  /*
  def numberPressed(number: Int): Unit={}
  def clearPressed(): Unit={this.self.bcode=""}
  def enterPressed(): Unit={}
  def checkoutPressed(): Unit={}
  def cashPressed(): Unit={}
  def creditPressed(): Unit={}
  def displayString(): String={""}
  def loyaltyCardPressed(): Unit={}
  */
  override def numberPressed(number: Int): Unit={
    this.self.bcode+=number
  }
  override def enterPressed(): Unit={
    this.self.cartlist = this.self.cartlist :+ this.self.storestuff.getOrElse(this.self.bcode, self.errormessage)
    this.self.state= new entering(this.self)
  }
  override def checkoutPressed(): Unit={
    this.self.state= new checkingOut(this.self)
  }
  override def displayString(): String={
    this.self.bcode
  }

}

