package store.model.items

abstract class Modifier {
  def updatePrice(x:Double):Double
  def computeTax(y:Double):Double

}
