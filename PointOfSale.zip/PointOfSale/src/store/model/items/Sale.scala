package store.model.items

class Sale(salespercentage:Double) extends Modifier(){

  override def updatePrice(updatedprice: Double):Double={
    updatedprice*(1-this.salespercentage*0.01)
  }
  override def computeTax(x:Double): Double={
    0.0
  }
}
