package store.model.items

class SalesTax (taxpercentage:Double) extends Modifier(){
  override def updatePrice(x:Double):Double={
  x
  }
  override def computeTax(price:Double):Double={
    this.taxpercentage*price*0.01
  }
}
