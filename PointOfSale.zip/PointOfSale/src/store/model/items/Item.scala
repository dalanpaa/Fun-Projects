package store.model.items

class Item(theDescription:String, basePriceLol:Double) {
  var bprice:Double=basePriceLol
  var modifier:List[Modifier]=List()

  // TODO: Complete this class according to the features listed in the HW document

  def description(): String = {
    this.theDescription
  }

  def price(): Double = {
    //this.modifier.head.updatePrice(bprice)
    var temp:Double=this.bprice
    for (i<-this.modifier){
      temp=i.updatePrice(temp)
    }
    temp
  }
  def setBasePrice(new_price:Double):Unit={
    this.bprice=new_price
  }
  def addModifier(mod:Modifier):Unit={
    this.modifier=mod::this.modifier
  }
  def tax():Double={
    //this.modifier.head.computeTax(bprice)
    var temp:Double=0
    for (i<-this.modifier){
      temp+=i.computeTax(price())
    }
    temp

  }

}
