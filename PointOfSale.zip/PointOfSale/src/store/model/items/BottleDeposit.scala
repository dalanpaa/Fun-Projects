package store.model.items

class BottleDeposit(deposit:Double) extends Modifier() {
  override def updatePrice(price:Double):Double={
    price
  }
  override def computeTax(x:Double):Double={
    this.deposit
  }
}
